class BreadcrumbItem {
  final String label;
  final String? route;

  BreadcrumbItem(this.label, {this.route});
}

class BreadcrumbResolver {
  static List<BreadcrumbItem> resolve(String? route) {
    if (route == null) return [];

    // Dashboard
    if (route == '/dashboard') {
      return [
        BreadcrumbItem('Dashboard'),
      ];
    }

    // PM
    if (route == '/pm/projects') {
      return [
        BreadcrumbItem('Project Management'),
      ];
    }

    // /pm/project/:id
    if (route.startsWith('/pm/project/') &&
        !route.endsWith('/tasks')) {
      return [
        BreadcrumbItem('Project Management', route: '/pm/projects'),
        BreadcrumbItem('Project'),
      ];
    }

    // /pm/project/:id/tasks
    if (route.endsWith('/tasks')) {
      return [
        BreadcrumbItem('Project Management', route: '/pm/projects'),
        BreadcrumbItem('Project'),
        BreadcrumbItem('Tasks'),
      ];
    }

    return [];
  }
}