import 'package:flutter/material.dart';
import 'package:flutter_admin_dashboard/pm/pm_on_generate_route.dart';
import 'package:flutter_admin_dashboard/theme/app_theme.dart';
import 'package:flutter_admin_dashboard/theme/jira_theme.dart';
import 'routes.dart';
import 'navigation/route_tracker.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      routes: routes,
      onGenerateRoute: pmOnGenerateRoute, // ✅ เพิ่ม
      initialRoute: '/',
      navigatorObservers: [
        RouteTracker(), // 👈 สำคัญ
      ],
    );
  }
}