import 'package:flutter/material.dart';

import '../widgets/sidebar.dart';
import '../pm/widgets/add_task_dialog.dart';
import '../pm/services/project_service.dart';
import '../pm/services/task_service.dart';

class AdminShell extends StatelessWidget {
  final Widget child;

  const AdminShell({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F7), // Jira background
      appBar: AppBar(
        elevation: 1,
        backgroundColor: Colors.white,
        titleSpacing: 16,
        title: const _JiraBreadcrumb(),
      ),
      body: Row(
        children: [
          const Sidebar(), // ❗ sidebar ไม่มี argument
          Expanded(child: child),
        ],
      ),
      floatingActionButton: _buildFab(context),
    );
  }

  /// ------------------------------------------------------------
  /// Floating Action Button (เฉพาะหน้า Kanban)
  /// ------------------------------------------------------------
  Widget? _buildFab(BuildContext context) {
    final route = ModalRoute.of(context)?.settings.name ?? '';

    // /pm/project/:id/tasks
    if (route.contains('/pm/project/') && route.endsWith('/tasks')) {
      final segments = Uri.parse(route).pathSegments;
      if (segments.length < 3) return null;

      final projectId = segments[2];

      return FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Add task'),
        backgroundColor: const Color(0xFF0052CC), // Jira blue
        onPressed: () {
          showDialog(
            context: context,
            builder: (_) => AddTaskDialog(projectId: projectId),
          );
        },
      );
    }

    return null;
  }
}

/// ============================================================
/// Jira-style Breadcrumb (AppBar)
/// ============================================================
class _JiraBreadcrumb extends StatelessWidget {
  const _JiraBreadcrumb();

  @override
  Widget build(BuildContext context) {
    final route = ModalRoute.of(context)?.settings.name ?? '';

    // ------------------------------------------------------------
    // /pm/my-tasks
    // ------------------------------------------------------------
    if (route == '/pm/my-tasks') {
      return StreamBuilder<Map<String, int>>(
        stream: TaskService.streamMyTaskStats(),
        builder: (context, snapshot) {
          final stats = snapshot.data ?? {
            'todo': 0,
            'doing': 0,
            'overdue': 0,
          };

          return Row(
            children: [
              _Crumb(
                icon: Icons.checklist,
                label: 'My tasks',
                badges: [
                  _Badge(
                    count: stats['todo']!,
                    color: const Color(0xFF0052CC),
                  ),
                  _Badge(
                    count: stats['doing']!,
                    color: const Color(0xFFFFAB00),
                  ),
                  _Badge(
                    count: stats['overdue']!,
                    color: const Color(0xFFDE350B),
                    icon: Icons.schedule,
                  ),
                ],
              ),
            ],
          );
        },
      );
    }

    // ------------------------------------------------------------
    // /pm/project/:id/tasks
    // ------------------------------------------------------------
    if (route.contains('/pm/project/') && route.endsWith('/tasks')) {
      final segments = Uri.parse(route).pathSegments;
      if (segments.length < 3) {
        return const SizedBox();
      }

      final projectId = segments[2];

      return FutureBuilder(
        future: ProjectService.getProject(projectId),
        builder: (context, snapshot) {
          final projectName = snapshot.data?.name ?? 'Project';

          return Row(
            children: [
              _Crumb(
                icon: Icons.folder,
                label: projectName,
              ),
              const _Separator(),
              const _Crumb(
                icon: Icons.view_kanban,
                label: 'Kanban',
              ),
            ],
          );
        },
      );
    }

    // ------------------------------------------------------------
    // default
    // ------------------------------------------------------------
    return const Text(
      'Admin',
      style: TextStyle(
        color: Color(0xFF172B4D),
        fontWeight: FontWeight.w600,
        fontSize: 14,
      ),
    );
  }
}

/// ============================================================
/// Breadcrumb item
/// ============================================================
class _Crumb extends StatelessWidget {
  final IconData icon;
  final String label;
  final List<_Badge>? badges;

  const _Crumb({
    required this.icon,
    required this.label,
    this.badges,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 18, color: const Color(0xFF172B4D)),
        const SizedBox(width: 6),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF172B4D),
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        if (badges != null)
          Row(
            children: badges!
                .where((b) => b.count > 0)
                .map(
                  (b) => Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: b,
                  ),
                )
                .toList(),
          ),
      ],
    );
  }
}

/// ============================================================
/// Separator ( / )
/// ============================================================
class _Separator extends StatelessWidget {
  const _Separator();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: Text(
        '/',
        style: TextStyle(
          color: Color(0xFF6B778C),
          fontSize: 14,
        ),
      ),
    );
  }
}

/// ============================================================
/// Badge (Jira style)
/// ============================================================
class _Badge extends StatelessWidget {
  final int count;
  final Color color;
  final IconData? icon;

  const _Badge({
    required this.count,
    required this.color,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    if (count <= 0) return const SizedBox();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: Colors.white),
            const SizedBox(width: 2),
          ],
          Text(
            count.toString(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}