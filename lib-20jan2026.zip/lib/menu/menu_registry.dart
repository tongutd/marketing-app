import 'package:flutter/material.dart';

class AdminMenu {
  final String key;
  final String label;
  final String route;
  final IconData icon;

  /// ⭐ สิทธิ์ที่เข้าได้
  final List<String> roles;

  const AdminMenu({
    required this.key,
    required this.label,
    required this.route,
    required this.icon,
    this.roles = const ['admin'], // default
  });
}

final List<AdminMenu> adminMenus = [
  AdminMenu(
    key: 'dashboard',
    label: 'Dashboard',
    route: '/dashboard',
    icon: Icons.dashboard,
    roles: ['admin', 'manager'],
  ),
  AdminMenu(
    key: 'pm_projects',
    label: 'Projects',
    route: '/pm/projects',
    icon: Icons.view_kanban,
    roles: ['admin', 'manager', 'staff'],
  ),
  AdminMenu(
    key: 'my_tasks',
    label: 'My Tasks',
    route: '/pm/my-tasks',
    icon: Icons.checklist,
    roles: ['admin', 'manager', 'staff'],
  ),
  AdminMenu(
    key: 'stores',
    label: 'Stores',
    route: '/stores',
    icon: Icons.store,
    roles: ['admin'],
  ),
];