import 'package:cloud_firestore/cloud_firestore.dart';

class TaskModel {
  final String id;
  final String title;
  final String description;

  /// todo, doing, done
  final String status;

  /// low, medium, high
  final String priority;

  final String? assignedTo;

  /// order within column (0..n)
  final int order;

  final DateTime createdAt;
  final DateTime updatedAt;

  const TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.status,
    required this.priority,
    required this.order,
    this.assignedTo,
    required this.createdAt,
    required this.updatedAt,
  });

  // ===============================
  // FROM FIRESTORE
  // ===============================

  factory TaskModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {

    final data = doc.data() ?? {};

    return TaskModel(
      id: doc.id,
      title: (data['title'] ?? '').toString(),
      description: (data['description'] ?? '').toString(),
      status: (data['status'] ?? 'todo').toString(),
      priority: (data['priority'] ?? 'medium').toString(),
      assignedTo: data['assignedTo']?.toString(),
      order: _toInt(data['order'], 0),
      createdAt: _toDate(data['createdAt']),
      updatedAt: _toDate(data['updatedAt']),
    );
  }

  // ===============================
  // TO FIRESTORE
  // ===============================

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'status': status,
      'priority': priority,
      'assignedTo': assignedTo,
      'order': order,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  // ===============================
  // COPY
  // ===============================

  TaskModel copyWith({
    String? id,
    String? title,
    String? description,
    String? status,
    String? priority,
    String? assignedTo,
    int? order,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return TaskModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      assignedTo: assignedTo ?? this.assignedTo,
      order: order ?? this.order,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // ===============================
  // UTILS
  // ===============================

  static int _toInt(dynamic v, int fallback) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v) ?? fallback;
    return fallback;
  }

  static DateTime _toDate(dynamic v) {
    if (v == null) return DateTime.now();
    if (v is Timestamp) return v.toDate();
    if (v is String) return DateTime.tryParse(v) ?? DateTime.now();
    return DateTime.now();
  }

  // ===============================
  // IMPORTANT: UI DUPLICATE PREVENTION
  // ===============================

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TaskModel && other.id == id);

  @override
  int get hashCode => id.hashCode;
}