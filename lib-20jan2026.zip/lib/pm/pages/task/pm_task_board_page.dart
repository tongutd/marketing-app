import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/task_provider.dart';
import '../../widgets/kanban_column.dart';
import '../../widgets/task_detail_dialog.dart';

class PMTaskBoardPage extends StatefulWidget {
  const PMTaskBoardPage({super.key});

  @override
  State<PMTaskBoardPage> createState() => _PMTaskBoardPageState();
}

class _PMTaskBoardPageState extends State<PMTaskBoardPage> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      context.read<TaskProvider>().startListen();
      _initialized = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PM Task Board'),
        actions: [
          IconButton(
            tooltip: 'Add task',
            onPressed: () => showAddTaskDialog(context),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: const Row(
        children: [
          KanbanColumn(title: 'TODO', status: 'todo'),
          KanbanColumn(title: 'DOING', status: 'doing'),
          KanbanColumn(title: 'DONE', status: 'done'),
        ],
      ),
    );
  }
}