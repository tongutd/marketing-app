import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../providers/task_provider.dart';
import '../../models/task_model.dart';
import '../widgets/task_card.dart';
import '../../widgets/task_detail_dialog.dart';

class PMMyTaskBoardPage extends StatefulWidget {
  const PMMyTaskBoardPage({super.key});

  @override
  State<PMMyTaskBoardPage> createState() => _PMMyTaskBoardPageState();
}

class _PMMyTaskBoardPageState extends State<PMMyTaskBoardPage> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialized) {
      context.read<TaskProvider>().startListen();
      _initialized = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    final provider = context.watch<TaskProvider>();
    final myTasks = provider.tasks.where((t) => t.assignedTo == uid).toList();

    // ถ้าอยากเรียงตาม order ที่คุณมีอยู่:
    myTasks.sort((a, b) => a.order.compareTo(b.order));

    return Scaffold(
      appBar: AppBar(title: const Text('My Tasks')),
      body: uid == null
          ? const Center(child: Text('Please login first'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: myTasks.length,
              itemBuilder: (context, i) {
                final task = myTasks[i];
                return InkWell(
                  onTap: () => showTaskDetailDialog(context, task),
                  child: TaskCard(
                    key: ValueKey(task.id),
                    task: task,
                  ),
                );
              },
            ),
    );
  }
}