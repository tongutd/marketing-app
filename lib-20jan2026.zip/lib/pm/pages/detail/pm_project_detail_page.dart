import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../models/project_model.dart';
import '../../services/project_service.dart';

class PMProjectDetailPage extends StatelessWidget {
  final String projectId;

  const PMProjectDetailPage({
    super.key,
    required this.projectId,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<ProjectModel?>(
      stream: FirebaseFirestore.instance
          .collection('projects')
          .doc(projectId)
          .snapshots()
          .map((doc) {
        if (!doc.exists) return null;
        return ProjectModel.fromFirestore(doc);
      }),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        final project = snapshot.data;

        if (project == null) {
          return const Center(
            child: Text(
              'Project not found',
              style: TextStyle(color: Colors.red),
            ),
          );
        }

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// --------------------------------------------------
              /// Header
              /// --------------------------------------------------
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    project.name,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),

                  Row(
                    children: [
                      /// ✅ View Tasks (Kanban)
                      ElevatedButton.icon(
                        icon: const Icon(Icons.view_kanban),
                        label: const Text('View Tasks'),
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/pm/project/${project.id}/tasks',
                          );
                        },
                      ),

                      const SizedBox(width: 8),

                      /// (เผื่ออนาคต) Edit Project
                      OutlinedButton.icon(
                        icon: const Icon(Icons.edit),
                        label: const Text('Edit'),
                        onPressed: () {
                          // TODO: open edit project dialog
                              showDialog(
                                context: context,
                                builder: (_) => _EditProjectDialog(project: project),
                        );
                        },
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 24),

              /// --------------------------------------------------
              /// Project Info
              /// --------------------------------------------------
              _InfoRow(
                label: 'Project ID',
                value: project.id,
              ),

              if (project.description != null &&
                  project.description!.isNotEmpty)
                _InfoRow(
                  label: 'Description',
                  value: project.description!,
                ),

              _InfoRow(
                label: 'Created At',
                value: project.createdAt != null
                    ? project.createdAt!
                        .toString()
                        .split('.')
                        .first
                    : '-',
              ),
            ],
          ),
        );
      },
    );
  }
}

/// --------------------------------------------------
/// Small reusable info row
/// --------------------------------------------------
class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.black54,
              ),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
class _EditProjectDialog extends StatefulWidget {
  final ProjectModel project;

  const _EditProjectDialog({required this.project});

  @override
  State<_EditProjectDialog> createState() => _EditProjectDialogState();
}

class _EditProjectDialogState extends State<_EditProjectDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _descCtrl;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.project.name);
    _descCtrl =
        TextEditingController(text: widget.project.description ?? '');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Project'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _nameCtrl,
            decoration: const InputDecoration(labelText: 'Project name'),
          ),
          TextField(
            controller: _descCtrl,
            decoration: const InputDecoration(labelText: 'Description'),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _saving
              ? null
              : () async {
                  setState(() => _saving = true);
                  await FirebaseFirestore.instance
                      .collection('projects')
                      .doc(widget.project.id)
                      .update({
                    'name': _nameCtrl.text.trim(),
                    'description': _descCtrl.text.trim(),
                  });
                  if (context.mounted) Navigator.pop(context);
                },
          child: const Text('Save'),
        ),
      ],
    );
  }
}