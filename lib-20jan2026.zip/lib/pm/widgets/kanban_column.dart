import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/task_provider.dart';
import 'task_card.dart';

class KanbanColumn extends StatelessWidget {

  final String title;
  final String status;

  const KanbanColumn({
    super.key,
    required this.title,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {

    final taskProvider = context.watch<TaskProvider>();

    // ดึง task ตาม status
    final tasks = taskProvider.byStatus(status);

    return Expanded(
      child: Card(
        margin: const EdgeInsets.all(8),
        child: Column(
          children: [

            // ---------- HEADER ----------
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    radius: 11,
                    backgroundColor: Colors.grey.shade300,
                    child: Text(
                      tasks.length.toString(),
                      style: const TextStyle(
                        fontSize: 11,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const Divider(height: 1),

            // ---------- LIST ----------
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(8),
                itemCount: tasks.length,
                itemBuilder: (context, index) {

                  final task = tasks[index];

                  return TaskCard(
                    key: ValueKey(task.id), // กัน UI duplicate
                    task: task,
                  );
                },
              ),
            ),

          ],
        ),
      ),
    );
  }
}