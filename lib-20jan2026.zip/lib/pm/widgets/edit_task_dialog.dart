import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../models/task_model.dart';

Future<void> showEditTaskDialog(BuildContext context, TaskModel task) async {
  final titleCtrl = TextEditingController(text: task.title);
  final descCtrl = TextEditingController(text: task.description);

  String status = task.status;
  String priority = task.priority;
  String? assignedTo = task.assignedTo;

  await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (ctx) {
      return AlertDialog(
        title: const Text('Edit Task'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Title',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: descCtrl,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: status,
                  items: const [
                    DropdownMenuItem(value: 'todo', child: Text('TODO')),
                    DropdownMenuItem(value: 'doing', child: Text('DOING')),
                    DropdownMenuItem(value: 'done', child: Text('DONE')),
                  ],
                  onChanged: (v) => status = v ?? task.status,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: priority,
                  items: const [
                    DropdownMenuItem(value: 'low', child: Text('Low')),
                    DropdownMenuItem(value: 'medium', child: Text('Medium')),
                    DropdownMenuItem(value: 'high', child: Text('High')),
                  ],
                  onChanged: (v) => priority = v ?? task.priority,
                  decoration: const InputDecoration(
                    labelText: 'Priority',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: TextEditingController(text: assignedTo ?? ''),
                  onChanged: (v) => assignedTo = v.trim().isEmpty ? null : v.trim(),
                  decoration: const InputDecoration(
                    labelText: 'AssignedTo (UID) (optional)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              titleCtrl.dispose();
              descCtrl.dispose();
              Navigator.pop(ctx);
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final title = titleCtrl.text.trim();
              if (title.isEmpty) return;

              final now = DateTime.now();

              await FirebaseFirestore.instance.collection('tasks').doc(task.id).update({
                'title': title,
                'description': descCtrl.text.trim(),
                'status': status,
                'priority': priority,
                'assignedTo': assignedTo,
                'updatedAt': Timestamp.fromDate(now),
              });

              titleCtrl.dispose();
              descCtrl.dispose();
              Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      );
    },
  );
}