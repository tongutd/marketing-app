import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../models/task_model.dart';
import 'edit_task_dialog.dart';

Future<void> showTaskDetailDialog(BuildContext context, TaskModel task) async {
  await showDialog(
    context: context,
    builder: (ctx) {
      return AlertDialog(
        title: Text(task.title),
        content: SizedBox(
          width: 560,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _row('Status', task.status),
              _row('Priority', task.priority),
              _row('AssignedTo', task.assignedTo ?? '-'),
              _row('Order', task.order.toString()),
              const SizedBox(height: 12),
              const Text('Description', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(task.description.isEmpty ? '-' : task.description),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
          TextButton(
            onPressed: () async {
              // Delete
              await FirebaseFirestore.instance.collection('tasks').doc(task.id).delete();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Delete'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await showEditTaskDialog(context, task);
            },
            child: const Text('Edit'),
          ),
        ],
      );
    },
  );
}

Widget _row(String k, String v) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Row(
      children: [
        SizedBox(width: 110, child: Text(k, style: const TextStyle(fontWeight: FontWeight.w600))),
        Expanded(child: Text(v)),
      ],
    ),
  );
}