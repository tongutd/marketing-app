import 'package:flutter/material.dart';

import '../layout/admin_shell.dart';

// ✅ IMPORT ให้ชัดเจน
import 'pages/task/pm_task_board_page.dart';
import 'pages/task/pm_my_task_board_page.dart';
import 'pages/detail/pm_project_detail_page.dart';

Route<dynamic>? pmOnGenerateRoute(RouteSettings settings) {
  final uri = Uri.parse(settings.name ?? '');

  /// -------------------------------
  /// /pm/my-tasks
  /// -------------------------------
  if (uri.path == '/pm/my-tasks') {
    return MaterialPageRoute(
      settings: settings,
      builder: (_) => const AdminShell(
        child: PMMyTaskBoardPage(),
      ),
    );
  }

  /// -------------------------------
  /// /pm/project/:id
  /// -------------------------------
  if (uri.pathSegments.length == 3 &&
      uri.pathSegments[0] == 'pm' &&
      uri.pathSegments[1] == 'project') {
    final projectId = uri.pathSegments[2];

    return MaterialPageRoute(
      settings: settings,
      builder: (_) => AdminShell(
        child: PMProjectDetailPage(projectId: projectId),
      ),
    );
  }

  /// -------------------------------
  /// /pm/project/:id/tasks
  /// -------------------------------
  if (uri.pathSegments.length == 4 &&
      uri.pathSegments[0] == 'pm' &&
      uri.pathSegments[1] == 'project' &&
      uri.pathSegments[3] == 'tasks') {
    final projectId = uri.pathSegments[2];

    // optional focusTaskId (มาจาก My Tasks)
    final args = settings.arguments as Map<String, dynamic>?;
    final focusTaskId = args?['focusTaskId'] as String?;

    return MaterialPageRoute(
      settings: settings,
      builder: (_) => AdminShell(
        child: PMTaskBoardPage(
          projectId: projectId,
          focusTaskId: focusTaskId,
        ),
      ),
    );
  }

  return null;
}