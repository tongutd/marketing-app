import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class UserService {
  static Stream<List<UserModel>> streamUsers() {
    return FirebaseFirestore.instance
        .collection('users') // ✅ users/{uid}
        // .where('active', isEqualTo: true)
        .snapshots()
        .map((snap) {
          return snap.docs.map((doc) {
            final data = doc.data();
            return UserModel(
              id: doc.id,
              displayName: data['displayName'] ?? 'User',
              email: data['email'] ?? '',
            );
          }).toList();
        });
  }
}