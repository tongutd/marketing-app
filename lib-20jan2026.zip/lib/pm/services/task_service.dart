import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/task_model.dart';

class TaskService {
  TaskService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('tasks');

  Stream<List<TaskModel>> watchTasks() {
    // ถ้ามี index/ต้องการเร็วขึ้น สามารถ orderBy status+order ได้
    return _col.snapshots().map((snap) {
      final list = snap.docs.map((d) => TaskModel.fromFirestore(d)).toList();

      // กันซ้ำด้วย id (กรณี merge หลายแหล่ง/บั๊กอื่น)
      final unique = <String, TaskModel>{};
      for (final t in list) {
        unique[t.id] = t;
      }
      return unique.values.toList();
    });
  }

  Future<void> updateTaskFields(String id, Map<String, dynamic> fields) async {
    await _col.doc(id).update(fields);
  }

  Future<void> batchUpdateOrders(List<TaskModel> tasks) async {
    final batch = _db.batch();
    final now = DateTime.now();

    for (final t in tasks) {
      final ref = _col.doc(t.id);
      batch.update(ref, {
        'order': t.order,
        'updatedAt': Timestamp.fromDate(now),
      });
    }
    await batch.commit();
  }

  Future<void> moveTask({
    required String taskId,
    required String newStatus,
    required int newOrder,
  }) async {
    final now = DateTime.now();
    await _col.doc(taskId).update({
      'status': newStatus,
      'order': newOrder,
      'updatedAt': Timestamp.fromDate(now),
    });
  }
}