import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  User? _user;
  bool _isLoading = true;
  String _role = 'member'; // member | admin | pm

  AuthProvider() {
    _init();
  }

  // =========================
  // INIT
  // =========================
  void _init() {
    _auth.authStateChanges().listen((user) async {
      _user = user;

      if (user != null) {
        await _loadUserRole(user.uid);
      } else {
        _role = 'member';
      }

      _isLoading = false;
      notifyListeners();
    });
  }

  // =========================
  // GETTERS
  // =========================
  User? get user => _user;

  bool get isLoading => _isLoading;

  bool get isLoggedIn => _user != null;

  String get role => _role;

  bool get isAdmin => _role == 'admin';

  bool get isPM => _role == 'pm';

  // =========================
  // LOGIN
  // =========================
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      final cred = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      _user = cred.user;

      if (_user != null) {
        await _loadUserRole(_user!.uid);
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('❌ Login error: $e');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // =========================
  // LOGOUT
  // =========================
  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    _role = 'member';
    notifyListeners();
  }

  // =========================
  // LOAD ROLE
  // =========================
  Future<void> _loadUserRole(String uid) async {
    try {
      final doc =
          await _db.collection('users').doc(uid).get();

      if (doc.exists) {
        _role = doc.data()?['role'] ?? 'member';
      } else {
        _role = 'member';
      }
    } catch (e) {
      debugPrint('⚠️ loadUserRole error: $e');
      _role = 'member';
    }
  }
}