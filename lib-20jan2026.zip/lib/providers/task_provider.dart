import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_admin_dashboard/pm/models/task_model.dart';

class TaskProvider extends ChangeNotifier {

  // ===============================
  // STATE
  // ===============================

  final List<TaskModel> _tasks = [];

  StreamSubscription? _taskSub;
  bool _isListening = false;

  // ===============================
  // GETTER
  // ===============================

  List<TaskModel> get tasks => List.unmodifiable(_tasks);

  List<TaskModel> byStatus(String status) {
    return _tasks.where((t) => t.status == status).toList();
  }

  // ===============================
  // FIRESTORE LISTENER
  // ===============================

  void startListen() {

    // กัน listen ซ้ำ
    if (_isListening) return;

    _isListening = true;

    // safety: cancel ของเก่าเสมอ
    _taskSub?.cancel();

    _taskSub = FirebaseFirestore.instance
        .collection('tasks')
        .snapshots()
        .listen((snapshot) {

      // clear ก่อนทุกครั้ง (fix duplicate)
      _tasks
        ..clear()
        ..addAll(
          snapshot.docs.map(
            (doc) => TaskModel.fromFirestore(doc),
          ),
        );

      notifyListeners();

    }, onError: (e) {

      // ถ้า stream error ให้ allow reconnect
      debugPrint('Task stream error: $e');
      _isListening = false;

    });
  }

  // ===============================
  // FORCE RELOAD (OPTIONAL)
  // ===============================

  void restartListen() {
    _isListening = false;
    _taskSub?.cancel();
    startListen();
  }

  // ===============================
  // CLEANUP
  // ===============================

  @override
  void dispose() {
    _taskSub?.cancel();
    _isListening = false;
    super.dispose();
  }
}