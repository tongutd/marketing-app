import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../layout/admin_shell.dart';

class AuthGate extends StatelessWidget {
  final Widget child;

  const AuthGate({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final routeName = ModalRoute.of(context)?.settings.name;

    // ⏳ รอ Firebase
    if (auth.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // 🚫 ยังไม่ login
    // ❗ ปล่อยให้ Navigator แสดง /login เอง
    if (!auth.isLoggedIn) {
      return child;
    }

    // ✅ login แล้ว
    // หน้า login ไม่ต้องมี shell
    if (routeName == '/login') {
      return child;
    }

    return AdminShell(child: child);
  }
}