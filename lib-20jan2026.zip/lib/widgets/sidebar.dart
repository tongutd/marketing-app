import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../menu/menu_registry.dart';
import '../providers/auth_provider.dart';

class Sidebar extends StatefulWidget {
  const Sidebar({super.key});

  @override
  State<Sidebar> createState() => _SidebarState();
}

class _SidebarState extends State<Sidebar> {
  bool _collapsed = false;

  @override
  Widget build(BuildContext context) {
    final currentRoute = ModalRoute.of(context)?.settings.name;
    final auth = context.watch<AuthProvider>();
    final userRole = auth.role ?? 'staff';

    /// ⭐ FILTER ตาม role
    final visibleMenus = adminMenus.where(
      (menu) => menu.roles.contains(userRole),
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: _collapsed ? 70 : 230,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          right: BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      child: Column(
        children: [
          /// Collapse
          Align(
            alignment:
                _collapsed ? Alignment.center : Alignment.centerRight,
            child: IconButton(
              icon: Icon(
                _collapsed
                    ? Icons.chevron_right
                    : Icons.chevron_left,
                color: Colors.grey.shade700,
              ),
              onPressed: () {
                setState(() => _collapsed = !_collapsed);
              },
            ),
          ),

          const Divider(),

          /// Menu
          Expanded(
            child: ListView(
              children: visibleMenus.map((menu) {
                final active = currentRoute != null &&
                    (currentRoute == menu.route ||
                        currentRoute
                            .startsWith('${menu.route}/'));

                return InkWell(
                  onTap: () {
                    if (currentRoute != menu.route) {
                      Navigator.pushNamed(context, menu.route);
                    }
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      color: active
                          ? const Color(0xFF1ABC9C)
                              .withOpacity(0.12)
                          : null,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          menu.icon,
                          size: 20,
                          color: active
                              ? const Color(0xFF1ABC9C)
                              : const Color(0xFF6B7280),
                        ),
                        if (!_collapsed) ...[
                          const SizedBox(width: 12),
                          Text(
                            menu.label,
                            style: TextStyle(
                              fontWeight: active
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                              color: active
                                  ? const Color(0xFF1ABC9C)
                                  : const Color(0xFF1F2937),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}