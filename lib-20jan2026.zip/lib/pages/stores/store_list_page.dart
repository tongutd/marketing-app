import 'package:flutter/material.dart';
import '../../services/store_service.dart';
import '../../models/store_model.dart';
import 'store_form_page.dart';

class StoreListPage extends StatelessWidget {
  const StoreListPage({super.key});

  @override
  Widget build(BuildContext context) {
    final service = StoreService();

    return Scaffold(
      appBar: AppBar(title: const Text('Stores')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                onPressed: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const StoreFormPage(),
                    ),
                  );

                  if (result == true && context.mounted) {
                    // 🔑 แก้ Snackbar ไม่ขึ้นบน Flutter Web
                    Future.delayed(const Duration(milliseconds: 300), () {
                      if (!context.mounted) return;

                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('บันทึกร้านค้าเรียบร้อยแล้ว'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    });
                  }
                },
                child: const Text('Add Store'),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: StreamBuilder<List<StoreModel>>(
                stream: service.getStores(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  final stores = snapshot.data!;
                  if (stores.isEmpty) {
                    return const Center(child: Text('No stores'));
                  }

                  return ListView.builder(
                    itemCount: stores.length,
                    itemBuilder: (_, i) {
                      final s = stores[i];
                      return ListTile(
                        title: Text(s.name),
                        subtitle: Text('BU: ${s.bu}'),
                        trailing: IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () async {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    StoreFormPage(store: s),
                              ),
                            );

                            if (result == true && context.mounted) {
                              Future.delayed(
                                  const Duration(milliseconds: 300), () {
                                if (!context.mounted) return;

                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content:
                                        Text('แก้ไขร้านค้าเรียบร้อยแล้ว'),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              });
                            }
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}