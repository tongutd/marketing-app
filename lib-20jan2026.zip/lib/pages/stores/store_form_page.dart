import 'package:flutter/material.dart';
import '../../models/store_model.dart';
import '../../services/store_service.dart';

class StoreFormPage extends StatefulWidget {
  final StoreModel? store;
  const StoreFormPage({super.key, this.store});

  @override
  State<StoreFormPage> createState() => _StoreFormPageState();
}

class _StoreFormPageState extends State<StoreFormPage> {
  final _idCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _buCtrl = TextEditingController();
  final _urlCtrl = TextEditingController();

  final StoreService service = StoreService();

  @override
  void initState() {
    super.initState();
    if (widget.store != null) {
      _idCtrl.text = widget.store!.id.toString();
      _nameCtrl.text = widget.store!.name;
      _buCtrl.text = widget.store!.bu;
      _urlCtrl.text = widget.store!.url;
    }
  }

  Future<void> _save() async {
    final store = StoreModel(
      id: int.parse(_idCtrl.text),
      name: _nameCtrl.text,
      bu: _buCtrl.text,
      url: _urlCtrl.text,
    );

    await service.addOrUpdate(store);

    if (mounted) {
      Navigator.pop(context, true); // 🔑 ส่งผลลัพธ์กลับ
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.store == null ? 'Add Store' : 'Edit Store'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: _idCtrl,
              decoration: const InputDecoration(labelText: 'Store ID'),
              enabled: widget.store == null,
            ),
            TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _buCtrl,
              decoration: const InputDecoration(labelText: 'BU'),
            ),
            TextField(
              controller: _urlCtrl,
              decoration: const InputDecoration(labelText: 'URL'),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _save,
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}